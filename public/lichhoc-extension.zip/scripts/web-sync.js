// LichHoc DTU Extension - Web App Session Sync
(function () {
  function syncSession() {
    const token = localStorage.getItem("lichhoc_access_token");
    const refreshToken = localStorage.getItem("lichhoc_refresh_token");
    const userStr = localStorage.getItem("lichhoc_user");

    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        chrome.storage.local.get(["token", "user"], (existing) => {
          if (existing.token !== token || JSON.stringify(existing.user) !== JSON.stringify(user)) {
            chrome.storage.local.set({ token, refresh_token: refreshToken, user });
          }
        });
      } catch (e) {
        // ignore JSON parse error
      }
    }
  }

  // Chạy ngay khi nạp trang
  syncSession();

  // Lắng nghe sự kiện storage
  window.addEventListener("storage", syncSession);

  // Nếu mở dạng popup từ Extension (?ext=1 hoặc ?source=extension), tự động đồng bộ và đóng cửa sổ sau khi đăng nhập thành công
  const isExtensionAuth =
    window.location.search.includes("ext=1") ||
    window.location.hash.includes("ext=1") ||
    window.location.search.includes("source=extension") ||
    window.location.hash.includes("source=extension");

  if (isExtensionAuth) {
    let attempts = 0;
    const checkInterval = setInterval(() => {
      attempts++;
      const token = localStorage.getItem("lichhoc_access_token");
      if (token) {
        syncSession();
        clearInterval(checkInterval);
        setTimeout(() => {
          window.close();
        }, 500);
      }
      if (attempts > 120) { // 60s timeout
        clearInterval(checkInterval);
      }
    }, 400);
  }
})();
