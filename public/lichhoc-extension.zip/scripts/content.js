// LichHoc DTU Extension - Content Script
// Chạy trên trang https://mydtu.duytan.edu.vn/sites/index.aspx?p=home_timetable*

(function () {
  const DAY_NAMES = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"];

  function parseAptTitle(title) {
    const parts = (title || "").split("|").map((p) => p.trim());
    const code = parts[0] || "";
    const subject = parts[1] || "";
    const roomLocation = parts[2] || "";
    const timeRange = parts[3] || "";

    let room = roomLocation;
    let location = "";
    if (roomLocation.includes(",")) {
      const rParts = roomLocation.split(",");
      room = rParts[0].trim();
      location = rParts.slice(1).join(",").trim();
    }

    let startTime = "07:00";
    let endTime = "09:00";
    const m = timeRange.match(/(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})/);
    if (m) {
      startTime = m[1];
      endTime = m[2];
    }

    return {
      class_code: code,
      subject: subject,
      room: room,
      location: location,
      start_time: startTime,
      end_time: endTime,
    };
  }

  function extractSchedule() {
    const container = document.querySelector(".main-border-center, #main-border-center, div[class*='main-border-center']");
    if (!container) {
      return {
        found: false,
        error: "Bạn vui lòng vào lịch học để lấy dữ liệu",
      };
    }

    const outerHTML = container.outerHTML;
    const events = [];

    // Tìm bảng rsContentTable bên trong container
    const contentTable = container.querySelector("table.rsContentTable") || container.querySelector("table");
    if (contentTable) {
      const rows = contentTable.querySelectorAll("tr");
      rows.forEach((row) => {
        const cells = Array.from(row.children).filter((el) => el.tagName === "TD");
        cells.forEach((cell, colIdx) => {
          const aptDivs = cell.querySelectorAll(".rsApt, .rsAptSimple, div[class*='rsApt']");
          aptDivs.forEach((apt) => {
            const title = apt.getAttribute("title") || "";
            if (!title) return;
            const parsed = parseAptTitle(title);
            parsed.day_index = colIdx;
            parsed.day_name = DAY_NAMES[colIdx] || `Cột ${colIdx}`;
            events.push(parsed);
          });
        });
      });
    }

    return {
      found: true,
      html: outerHTML,
      events: events,
      count: events.length,
    };
  }

  // Lắng nghe yêu cầu từ popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "EXTRACT_SCHEDULE") {
      const result = extractSchedule();
      sendResponse(result);
    }
    return true;
  });
})();
