// LichHoc DTU Extension - Service Worker (Manifest V3)
chrome.runtime.onInstalled.addListener(() => {
  console.log("LichHoc DTU Extension đã được cài đặt thành công.");
});

// Lắng nghe messages từ popup hoặc content script nếu cần gửi API qua background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "SAVE_SCHEDULE") {
    const { token, html, events } = message.payload;
    fetch("http://127.0.0.1:3001/api/schedule", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
      body: JSON.stringify({ html, events }),
    })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "Lỗi khi lưu lịch vào Backend.");
        }
        sendResponse({ success: true, data });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message });
      });
    return true; // Giữ kênh async
  }
});
