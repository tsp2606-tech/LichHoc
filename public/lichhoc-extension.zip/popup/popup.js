// LichHoc DTU Extension - Popup Script

const API_BASE_URL = "http://127.0.0.1:3001";
const TARGET_TIMETABLE_URL = "https://mydtu.duytan.edu.vn/sites/index.aspx?p=home_timetable&functionid=13";
const REQUIRED_WARNING_MSG = "Bạn vui lòng vào lịch học để lấy dữ liệu";

// DOM Elements
const authSection = document.getElementById("auth-section");
const mainSection = document.getElementById("main-section");
const loginForm = document.getElementById("login-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const btnLogin = document.getElementById("btn-login");
const authError = document.getElementById("auth-error");

const userEmailSpan = document.getElementById("user-email");
const btnLogout = document.getElementById("btn-logout");
const btnExtract = document.getElementById("btn-extract");
const statusBox = document.getElementById("status-box");
const statusIcon = document.getElementById("status-icon");
const statusMessage = document.getElementById("status-message");
const btnOpenFe = document.getElementById("btn-open-fe");
const btnGoogleLogin = document.getElementById("btn-google-login");
const userAvatarImg = document.getElementById("user-avatar-img");
const userAvatarFallback = document.getElementById("user-avatar-fallback");

// Week Picker & Progress DOM Elements
const inputWeeks = document.getElementById("input-weeks");
const btnDecWeek = document.getElementById("btn-dec-week");
const btnIncWeek = document.getElementById("btn-inc-week");
const progressBox = document.getElementById("progress-box");
const progressCounter = document.getElementById("progress-counter");
const progressFill = document.getElementById("progress-fill");
const progressDetail = document.getElementById("progress-detail");

function updateStepperButtons() {
  if (!inputWeeks) return;
  const val = parseInt(inputWeeks.value, 10) || 1;
  if (btnDecWeek) btnDecWeek.disabled = val <= 1;
  if (btnIncWeek) btnIncWeek.disabled = val >= 5;
}

if (btnDecWeek) {
  btnDecWeek.addEventListener("click", () => {
    let val = parseInt(inputWeeks.value, 10) || 1;
    if (val > 1) {
      val--;
      inputWeeks.value = val;
    }
    updateStepperButtons();
  });
}

if (btnIncWeek) {
  btnIncWeek.addEventListener("click", () => {
    let val = parseInt(inputWeeks.value, 10) || 1;
    if (val < 5) {
      val++;
      inputWeeks.value = val;
    }
    updateStepperButtons();
  });
}

function updateProgressUI(currentWeek, totalWeeks, detailText) {
  if (progressBox) progressBox.style.display = "flex";
  if (progressCounter) progressCounter.textContent = `${currentWeek}/${totalWeeks}`;
  const pct = Math.max(5, Math.min(100, Math.round((currentWeek / totalWeeks) * 100)));
  if (progressFill) progressFill.style.width = `${pct}%`;
  if (progressDetail) progressDetail.textContent = detailText;
}

function hideProgressUI() {
  if (progressBox) progressBox.style.display = "none";
  if (progressFill) progressFill.style.width = "0%";
  if (progressCounter) progressCounter.textContent = "0/1";
  if (progressDetail) progressDetail.textContent = "";
}

// Error Dialog DOM Elements
const errorDialogBackdrop = document.getElementById("error-dialog-backdrop");
const dialogTitle = document.getElementById("dialog-title");
const dialogCode = document.getElementById("dialog-code");
const dialogMessage = document.getElementById("dialog-message");
const btnCloseDialogX = document.getElementById("btn-close-dialog-x");
const btnDialogOk = document.getElementById("btn-dialog-ok");

function showErrorDialog(title, message, code = "") {
  let cleanMessage = String(message || "Đã xảy ra lỗi, vui lòng kiểm tra lại.");
  cleanMessage = cleanMessage.replace(/https?:\/\/[^\s\)\],]+/gi, "máy chủ API");
  cleanMessage = cleanMessage.replace(/localhost(:\d+)?/gi, "máy chủ API");
  cleanMessage = cleanMessage.replace(/127\.0\.0\.1(:\d+)?/gi, "máy chủ API");
  cleanMessage = cleanMessage.replace(/mydtu\.duytan\.edu\.vn[^\s\)\],]*/gi, "cổng đào tạo");
  if (dialogTitle) dialogTitle.textContent = title || "Thông báo lỗi";
  if (dialogMessage) dialogMessage.textContent = cleanMessage;
  if (dialogCode) {
    if (code) {
      dialogCode.textContent = `Mã: ${code}`;
      dialogCode.style.display = "inline-block";
    } else {
      dialogCode.style.display = "none";
    }
  }
  if (errorDialogBackdrop) {
    errorDialogBackdrop.style.display = "flex";
  }
}

function hideErrorDialog() {
  if (errorDialogBackdrop) {
    errorDialogBackdrop.style.display = "none";
  }
}

if (btnCloseDialogX) btnCloseDialogX.addEventListener("click", hideErrorDialog);
if (btnDialogOk) btnDialogOk.addEventListener("click", hideErrorDialog);
if (errorDialogBackdrop) {
  errorDialogBackdrop.addEventListener("mousedown", (e) => {
    if (e.target === errorDialogBackdrop) hideErrorDialog();
  });
}

// Khởi tạo trạng thái đăng nhập từ chrome.storage
document.addEventListener("DOMContentLoaded", async () => {
  const data = await chrome.storage.local.get(["token", "user"]);
  if (data.token && data.user) {
    showMainView(data.user);
  } else {
    showAuthView();
  }
});

function showAuthView() {
  authSection.style.display = "block";
  mainSection.style.display = "none";
  clearStatus();
}

function showMainView(user) {
  authSection.style.display = "none";
  mainSection.style.display = "block";
  userEmailSpan.textContent = user?.name ? `${user.name} (${user.email})` : (user?.email || "Sinh viên");

  if (user?.avatar) {
    if (userAvatarImg) {
      userAvatarImg.src = user.avatar;
      userAvatarImg.style.display = "block";
    }
    if (userAvatarFallback) {
      userAvatarFallback.style.display = "none";
    }
  } else {
    if (userAvatarImg) userAvatarImg.style.display = "none";
    if (userAvatarFallback) userAvatarFallback.style.display = "inline";
  }
  clearStatus();
}

function showStatus(type, message) {
  statusBox.className = `status-box ${type}`;
  statusBox.style.display = "flex";
  if (type === "warning") {
    statusIcon.textContent = "⚠️";
  } else if (type === "success") {
    statusIcon.textContent = "✅";
  } else {
    statusIcon.textContent = "❌";
  }
  statusMessage.textContent = message;
}

function clearStatus() {
  statusBox.style.display = "none";
  statusBox.className = "status-box";
  statusMessage.textContent = "";
}

// Xử lý Đăng Nhập
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  authError.style.display = "none";
  authError.textContent = "";

  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    authError.textContent = "Vui lòng nhập đầy đủ email và mật khẩu.";
    authError.style.display = "block";
    showErrorDialog(
      "Thiếu thông tin đăng nhập",
      "Vui lòng nhập đầy đủ Email sinh viên và Mật khẩu để tiếp tục.",
      "VALIDATION_ERROR"
    );
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    authError.textContent = "Email không đúng định dạng.";
    authError.style.display = "block";
    showErrorDialog(
      "Email không hợp lệ",
      "Địa chỉ email không đúng định dạng. Vui lòng nhập đúng email (Ví dụ: student@example.com).",
      "INVALID_EMAIL"
    );
    return;
  }

  // Bật spinner
  btnLogin.disabled = true;
  btnLogin.querySelector(".btn-text").textContent = "Đang đăng nhập...";
  btnLogin.querySelector(".btn-spinner").style.display = "inline-block";

  try {
    const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, remember_me: true }),
    });

    const text = await res.text();
    let data = {};
    try {
      data = JSON.parse(text);
    } catch {
      const errText = "Lỗi máy chủ API. Vui lòng thử lại sau.";
      showErrorDialog("Lỗi API", errText, String(res.status));
      throw new Error(errText);
    }

    if (!res.ok) {
      const errMsg = data.error || "Email hoặc mật khẩu không chính xác.";
      showErrorDialog("Đăng nhập thất bại", errMsg, String(res.status));
      throw new Error(errMsg);
    }

    // Lưu token, refresh_token & user vào chrome.storage.local
    await chrome.storage.local.set({
      token: data.access_token,
      refresh_token: data.refresh_token || null,
      user: data.user,
    });

    showMainView(data.user);
  } catch (err) {
    authError.textContent = err.message || "Không thể kết nối đến máy chủ API.";
    authError.style.display = "block";
    if (errorDialogBackdrop && errorDialogBackdrop.style.display !== "flex") {
      showErrorDialog("Lỗi đăng nhập", err.message || "Không thể kết nối đến máy chủ API.", "LOGIN_ERROR");
    }
  } finally {
    btnLogin.disabled = false;
    btnLogin.querySelector(".btn-text").textContent = "Đăng nhập";
    btnLogin.querySelector(".btn-spinner").style.display = "none";
  }
});

// Xử lý Đăng Xuất
btnLogout.addEventListener("click", async () => {
  await chrome.storage.local.remove(["token", "refresh_token", "user"]);
  emailInput.value = "";
  passwordInput.value = "";
  showAuthView();
});

// Nút mở Frontend
btnOpenFe.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "http://localhost:4174/#/calendar" });
});

// Xử lý Đăng nhập Google qua Web App
if (btnGoogleLogin) {
  btnGoogleLogin.addEventListener("click", () => {
    chrome.tabs.create({
      url: "http://localhost:4174/#/login?source=extension",
    });
    window.close();
  });
}

// Lắng nghe thay đổi storage từ web-sync hoặc tab khác
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local") {
    if (changes.user && changes.user.newValue) {
      showMainView(changes.user.newValue);
    } else if (changes.token && !changes.token.newValue) {
      showAuthView();
    }
  }
});

// Kiểm tra URL xem có đúng trang lịch học myDTU không
function isTimetableUrl(url) {
  if (!url) return false;
  return (
    url.includes("mydtu.duytan.edu.vn") &&
    (url.includes("home_timetable") || url.includes("functionid=13") || url.includes("timetable"))
  );
}

// Xử lý Lấy Dữ Liệu Lịch Học
btnExtract.addEventListener("click", async () => {
  clearStatus();

  // 1. Kiểm tra đăng nhập
  const { token } = await chrome.storage.local.get("token");
  if (!token) {
    showStatus("error", "Bạn chưa đăng nhập. Vui lòng đăng nhập lại.");
    showErrorDialog("Phiên làm việc hết hạn", "Bạn chưa đăng nhập hoặc phiên đã hết hạn. Vui lòng đăng nhập lại.", "401");
    showAuthView();
    return;
  }

  // 2. Lấy tab hiện tại
  let tab;
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = tabs[0];
  } catch (err) {
    showStatus("error", "Không thể truy cập tab hiện tại: " + err.message);
    showErrorDialog("Lỗi truy cập tab", "Không thể lấy thông tin tab trình duyệt: " + err.message, "TAB_ERROR");
    return;
  }

  if (!tab || !tab.url) {
    showStatus("warning", REQUIRED_WARNING_MSG);
    showErrorDialog("Chưa vào lịch học", REQUIRED_WARNING_MSG, "TAB_INVALID");
    return;
  }

  // 3. Kiểm tra xem có đúng trang lịch học myDTU không
  if (!isTimetableUrl(tab.url)) {
    showStatus("warning", REQUIRED_WARNING_MSG);
    showErrorDialog(
      "Chưa vào lịch học",
      `${REQUIRED_WARNING_MSG}.\n\nVui lòng mở đúng trang Thời khóa biểu trên cổng đào tạo myDTU.`,
      "URL_INVALID"
    );
    return;
  }

  const targetWeeks = Math.min(5, Math.max(1, parseInt(inputWeeks?.value || "1", 10)));
  const allEventsMap = new Map();
  let firstHtml = "";
  let weeksScanned = 0;

  btnExtract.disabled = true;
  btnExtract.querySelector(".btn-text").textContent = `Đang quét (1/${targetWeeks})...`;
  btnExtract.querySelector(".btn-spinner").style.display = "inline-block";

  try {
    for (let w = 1; w <= targetWeeks; w++) {
      // Cập nhật giao diện tiến trình thực tế: ví dụ 1/5, 2/5...
      updateProgressUI(w, targetWeeks, `Đang quét dữ liệu tuần ${w}/${targetWeeks}...`);
      btnExtract.querySelector(".btn-text").textContent = `Đang quét (${w}/${targetWeeks})...`;

      // 4. Trích xuất dữ liệu của tuần hiện tại trên trang
      const injectionResults = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const container = document.querySelector(".main-border-center, #main-border-center, div[class*='main-border-center']");
          if (!container) {
            return { found: false };
          }

          const DAY_NAMES = ["Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7", "Chủ nhật"];
          const headerH2 = document.querySelector(".rsHeader h2, h2");
          const weekRange = headerH2 ? headerH2.textContent.trim() : "";
          const events = [];

          // Tìm bảng rsContentTable
          const contentTable = container.querySelector("table.rsContentTable") || container.querySelector("table");
          if (contentTable) {
            const rows = contentTable.querySelectorAll("tr");
            rows.forEach((row) => {
              const cells = Array.from(row.children).filter((el) => el.tagName === "TD");
              cells.forEach((cell, colIdx) => {
                const aptDivs = cell.querySelectorAll(".rsApt, .rsAptSimple, div[class*='rsApt']");
                aptDivs.forEach((apt) => {
                  const title = apt.getAttribute("title") || "";
                  if (!title || !title.includes("|")) return;

                  const parts = title.split("|").map((p) => p.trim());
                  const classCode = parts[0] || "";
                  const subject = parts[1] || "";
                  const roomLocation = parts[2] || "";
                  const timeRange = parts[3] || "";

                  let room = roomLocation;
                  let location = "";
                  if (roomLocation.includes(",")) {
                    const rParts = roomLocation.split(",");
                    room = rParts[0].trim();
                    location = rParts.slice(1).join(",").trim();
                  }

                  let startTime = "07:00";
                  let endTime = "09:00";
                  const m = timeRange.match(/(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})/);
                  if (m) {
                    startTime = m[1];
                    endTime = m[2];
                  }

                  events.push({
                    class_code: classCode,
                    subject: subject,
                    room: room,
                    location: location,
                    start_time: startTime,
                    end_time: endTime,
                    day_index: colIdx,
                    day_name: DAY_NAMES[colIdx] || `Cột ${colIdx}`,
                    week_range: weekRange,
                  });
                });
              });
            });
          }

          return {
            found: true,
            html: container.outerHTML,
            events: events,
            weekRange: weekRange,
            count: events.length,
          };
        },
      });

      const result = injectionResults?.[0]?.result;

      // Nếu tuần đầu tiên không tìm thấy div main-border-center -> Báo lỗi đúng yêu cầu
      if (!result || !result.found) {
        if (w === 1) {
          hideProgressUI();
          showStatus("warning", REQUIRED_WARNING_MSG);
          showErrorDialog(
            "Không tìm thấy lịch học",
            `${REQUIRED_WARNING_MSG}.\n\nHệ thống không tìm thấy khung lịch học (.main-border-center) trên trang bạn đang xem.`,
            "NOT_FOUND_DIV"
          );
          return;
        }
        // Nếu các tuần sau không còn tìm thấy khung lịch -> dừng và lưu dữ liệu đã quét được
        break;
      }

      if (!firstHtml) firstHtml = result.html;
      weeksScanned++;

      // Gom môn học và tự động gộp (deduplicate) các môn học trùng lặp trong từng tuần
      (result.events || []).forEach((ev) => {
        const weekKey = (ev.week_range || "").trim();
        const key = `${weekKey}_${ev.day_index}_${ev.class_code}_${ev.subject}_${ev.start_time}_${ev.end_time}_${ev.room}`;
        if (!allEventsMap.has(key)) {
          allEventsMap.set(key, ev);
        }
      });

      // Nếu còn tuần tiếp theo cần quét -> Bấm nút Next Day và chờ DOM cập nhật
      if (w < targetWeeks) {
        updateProgressUI(w, targetWeeks, `Đã quét xong tuần ${w}/${targetWeeks}. Đang bấm Next Day sang tuần ${w + 1}/${targetWeeks}...`);

        const nextRes = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (oldWeekRange) => {
            return new Promise((resolve) => {
              const nextBtn = document.querySelector("a.rsNextDay, .rsHeader a.rsNextDay, p a.rsNextDay");
              if (!nextBtn) {
                resolve({ success: false, reason: "NOT_FOUND_NEXT_BUTTON" });
                return;
              }

              const previousText = oldWeekRange || document.querySelector(".rsHeader h2, h2")?.textContent?.trim() || "";
              let done = false;

              const finish = (res) => {
                if (done) return;
                done = true;
                if (pollTimer) clearInterval(pollTimer);
                if (observer) observer.disconnect();
                if (safetyTimer) clearTimeout(safetyTimer);
                setTimeout(() => resolve(res), 350);
              };

              // Timeout an toàn sau 8 giây
              const safetyTimer = setTimeout(() => {
                const curH2 = document.querySelector(".rsHeader h2, h2");
                const curText = curH2 ? curH2.textContent.trim() : "";
                finish({ success: curText !== previousText, timeout: true, newWeekRange: curText });
              }, 8000);

              // Polling kiểm tra trạng thái
              const pollTimer = setInterval(() => {
                const curH2 = document.querySelector(".rsHeader h2, h2");
                const curText = curH2 ? curH2.textContent.trim() : "";
                const loading = document.querySelector(".loading-calendar, .RadAjaxLoadingPanel");
                const isVisible = loading && loading.style.display !== "none" && loading.offsetParent !== null;

                if (curText && curText !== previousText && !isVisible) {
                  const container = document.querySelector(".main-border-center");
                  if (container && container.firstElementChild) {
                    finish({ success: true, newWeekRange: curText });
                  }
                }
              }, 200);

              // MutationObserver bắt thay đổi DOM
              const target = document.querySelector(".main-border-center") || document.body;
              const observer = new MutationObserver(() => {
                const curH2 = document.querySelector(".rsHeader h2, h2");
                const curText = curH2 ? curH2.textContent.trim() : "";
                const loading = document.querySelector(".loading-calendar, .RadAjaxLoadingPanel");
                const isVisible = loading && loading.style.display !== "none" && loading.offsetParent !== null;

                if (curText && curText !== previousText && !isVisible) {
                  const container = document.querySelector(".main-border-center");
                  if (container && container.firstElementChild) {
                    finish({ success: true, newWeekRange: curText });
                  }
                }
              });

              observer.observe(target, { childList: true, subtree: true, characterData: true });

              // Click chuyển tuần
              nextBtn.click();
            });
          },
          args: [result.weekRange],
        });

        const nextResult = nextRes?.[0]?.result;
        if (!nextResult || (!nextResult.success && !nextResult.timeout)) {
          // Không thể next tiếp (tuần cuối)
          break;
        }

        await new Promise((r) => setTimeout(r, 300));
      }
    }

    const finalEvents = Array.from(allEventsMap.values());
    updateProgressUI(targetWeeks, targetWeeks, "Đang tổng hợp dữ liệu & lưu lên máy chủ...");
    btnExtract.querySelector(".btn-text").textContent = "Đang lưu vào hệ thống...";

    // 5. Gửi dữ liệu lên Backend
    let sendToken = token;
    let res = await fetch(`${API_BASE_URL}/api/schedule`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${sendToken}`,
      },
      body: JSON.stringify({
        html: firstHtml,
        events: finalEvents,
      }),
    });

    // Nếu token hết hạn (401), tự động dùng refresh_token để lấy token mới và gửi lại
    if (res.status === 401) {
      const storageData = await chrome.storage.local.get(["refresh_token"]);
      if (storageData.refresh_token) {
        try {
          const refreshRes = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ refresh_token: storageData.refresh_token }),
          });
          if (refreshRes.ok) {
            const refreshData = await refreshRes.json();
            if (refreshData.access_token) {
              sendToken = refreshData.access_token;
              await chrome.storage.local.set({ token: sendToken });
              res = await fetch(`${API_BASE_URL}/api/schedule`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${sendToken}`,
                },
                body: JSON.stringify({
                  html: firstHtml,
                  events: finalEvents,
                }),
              });
            }
          }
        } catch {
          // Refresh thất bại
        }
      }
    }

    const resText = await res.text();
    let resData = {};
    try {
      resData = JSON.parse(resText);
    } catch {
      const errText = "Lỗi máy chủ API. Vui lòng thử lại sau.";
      showErrorDialog("Lỗi API", errText, String(res.status));
      throw new Error(errText);
    }

    if (!res.ok) {
      const errMsg = resData.error || "Lỗi khi lưu dữ liệu lên máy chủ.";
      showErrorDialog("Lỗi lưu lịch học", errMsg, String(res.status));
      throw new Error(errMsg);
    }

    const savedCount = resData.count ?? finalEvents.length;
    updateProgressUI(targetWeeks, targetWeeks, `Đã hoàn tất quét ${weeksScanned}/${targetWeeks} tuần!`);
    showStatus(
      "success",
      `Đã quét thành công ${weeksScanned}/${targetWeeks} tuần! Lưu thành công ${savedCount} môn học vào tài khoản. Bạn có thể vào Frontend để xem lịch.`
    );
  } catch (err) {
    showStatus("error", err.message || "Có lỗi xảy ra khi lấy dữ liệu.");
    if (errorDialogBackdrop && errorDialogBackdrop.style.display !== "flex") {
      showErrorDialog("Lỗi lấy dữ liệu lịch học", err.message || "Có lỗi xảy ra khi lấy dữ liệu từ trang web.", "EXTRACT_ERROR");
    }
  } finally {
    btnExtract.disabled = false;
    btnExtract.querySelector(".btn-text").textContent = "Lấy dữ liệu lịch học";
    btnExtract.querySelector(".btn-spinner").style.display = "none";
  }
});

